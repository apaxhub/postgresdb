--
-- PostgreSQL database dump
--

\restrict WzdgxpsJq9yhB8IOrVQpOcv2nk8BMr3VQrtfHJxKvmGKGhuQD6oTvhdiKutGQYS

-- Dumped from database version 17.7
-- Dumped by pg_dump version 18.0 (Debian 18.0-1.pgdg13+3)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Customer; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public."Customer" (
    id text NOT NULL,
    name text NOT NULL,
    address text NOT NULL,
    "gstNumber" text NOT NULL,
    "userId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Customer" OWNER TO app_user;

--
-- Name: Expenses; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public."Expenses" (
    id text NOT NULL,
    type text NOT NULL,
    description text NOT NULL,
    amount integer NOT NULL,
    "expenseDate" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."Expenses" OWNER TO app_user;

--
-- Name: Invoice; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public."Invoice" (
    id text NOT NULL,
    "invoiceNumber" text NOT NULL,
    "organizationId" text NOT NULL,
    "userId" text NOT NULL,
    "customerId" text,
    "billerName" text,
    "invoiceType" text NOT NULL,
    items jsonb NOT NULL,
    "totalAmount" double precision NOT NULL,
    "vehicalNumber" text NOT NULL,
    "gstAmount" double precision NOT NULL,
    "grandTotal" double precision NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "gstPercentage" integer DEFAULT 18 NOT NULL,
    uplak text
);


ALTER TABLE public."Invoice" OWNER TO app_user;

--
-- Name: Organization; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public."Organization" (
    id text NOT NULL,
    name text NOT NULL,
    "gstNumber" text NOT NULL,
    logo text,
    address text NOT NULL,
    "bankName" text NOT NULL,
    "accountNumber" text NOT NULL,
    "ifscCode" text NOT NULL,
    policy text,
    "userId" text NOT NULL,
    "invoiceCount" integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "fireWoodInvoiceCount" integer DEFAULT 0 NOT NULL
);


ALTER TABLE public."Organization" OWNER TO app_user;

--
-- Name: PaymentLog; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public."PaymentLog" (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    amount text NOT NULL,
    note text,
    "paymentDate" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "creditBillsId" text
);


ALTER TABLE public."PaymentLog" OWNER TO app_user;

--
-- Name: Subscription; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public."Subscription" (
    id text NOT NULL,
    endpoint text NOT NULL,
    p256dh text NOT NULL,
    auth text NOT NULL
);


ALTER TABLE public."Subscription" OWNER TO app_user;

--
-- Name: User; Type: TABLE; Schema: public; Owner: app_user
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    password text,
    username text NOT NULL
);


ALTER TABLE public."User" OWNER TO app_user;

--
-- Data for Name: Customer; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public."Customer" (id, name, address, "gstNumber", "userId", "createdAt", "updatedAt") FROM stdin;
804083c6-f3fe-4d3c-9c1b-b109e76569d8	Mahavir Timber Industries	Block No. 725-A-1, Kubadthal Road, Opp. Shiv Bhoomi Ind. Estate, Kubadthal, Ta. Dascroi, Ahmedabad-382430, Gujarat	24AAVFM8021E1Z8	215ed277-0f13-40ec-868e-bf9c0699151a	2025-04-25 12:44:47.979	2025-04-25 12:44:47.979
a395f4f8-2990-4cee-9f47-c18879bf11cd	Mahalaxmi Saw Mill	Odhav, Ahmedabad, Gujarat	24AAKFS0401P1Z6	215ed277-0f13-40ec-868e-bf9c0699151a	2025-04-25 12:46:57.549	2025-04-25 12:46:57.549
057edbbd-6c9b-4831-9a8a-50f101941ffe	Kalyani Timber Mart	PLOT NO :- 12 DAGALA, SPAN CHANDAN MALL ROAD VISNAGAR -384315	24AACFK3902H1ZR	215ed277-0f13-40ec-868e-bf9c0699151a	2025-04-25 12:48:23.5	2025-04-25 12:48:23.5
fba9bd5f-a23d-4813-8a14-9e1c40d7eb82	JALARAM TRADING CO.	Plot no-59,60,83,84,85,gidc kheralu kheralu - 384325 Gujarat	24DTKPP7923K1Z3	215ed277-0f13-40ec-868e-bf9c0699151a	2025-05-03 05:10:06.47	2025-05-03 05:10:06.47
71ac6a37-0fad-47a0-b477-895e88a68f7d	JALARAM SAW MILL	Nr.-Shalaka Society, At.-Shalaka, TA- Visnagar,Dist.- Mehsana.(N.G.),Pin No. 383315	24BFRPP0747Q2ZM	215ed277-0f13-40ec-868e-bf9c0699151a	2025-05-03 05:12:49.084	2025-05-03 05:12:49.084
cd64515e-c258-432d-bd8f-2629ddfd4c0e	SHREE SHAKTI VIJAY SAW MILL	Shunshi Road, Visnagar. (Guj.) 384315	24BGDPP51241Z8	215ed277-0f13-40ec-868e-bf9c0699151a	2025-05-03 05:14:28.089	2025-05-03 05:14:28.089
06d7b938-c2ea-47bd-adc6-b1699cb51899	Ambika Timber Industries	Sec-28 GIDC, Gandhinagar, Gujarat	24ACOPP7392N1ZO	215ed277-0f13-40ec-868e-bf9c0699151a	2025-05-03 05:18:37.423	2025-05-03 05:18:37.423
9ce9028c-ae02-40be-87dc-420cca36f7d5	Mahalaxmi WoodenBox Industries	Opp-C.M.C.(India), Odhav, Ahmedabad, Gujarat	24AAEFM2777L1ZZ	215ed277-0f13-40ec-868e-bf9c0699151a	2025-05-03 05:20:04.218	2025-05-03 05:20:04.218
4a15a7c9-7bd6-4403-b730-8ce40373d509	SHREE SHAKTI TRADERS	Shunshi Road, Visnagar. (Guj.) 384315	24AGWPP6688B1ZS	215ed277-0f13-40ec-868e-bf9c0699151a	2025-05-10 04:20:37.079	2025-05-10 04:20:37.079
62dc0f85-edb0-4857-8055-1d44742ef857	SHRI UMIYAKRUPA TRADERS	Linch, Gujarat	24BBKPP3139B1ZX	215ed277-0f13-40ec-868e-bf9c0699151a	2025-06-03 13:54:46.765	2025-06-03 13:54:46.765
b947757b-6c7f-4cca-a6b6-79a16981c050	G.N SAW MILLS 	Near Resam From CHANGEDI Teh. Mali Dist. Udaipur (Raj)-313205	08BJZPK5747B1ZQ	215ed277-0f13-40ec-868e-bf9c0699151a	2025-06-15 06:09:35.245	2025-06-15 06:09:35.245
9d33e21c-8018-4cd8-b324-09d70ee38239	Sarkar Enterprieses	Daroli, Rajasthan	08ENHPB9037E1Z8	215ed277-0f13-40ec-868e-bf9c0699151a	2025-07-06 12:33:00.673	2025-07-06 12:33:00.673
358185d5-0d27-4a58-a1f8-b7bdcc60302b	D S SAW MILLS	CHANGEDI DANG, Fatehnagar, Ta. Malvi,Di. Udaypur, Rajasthan.	08FGPPP7302J1ZU	215ed277-0f13-40ec-868e-bf9c0699151a	2025-08-14 04:23:14.052	2025-08-14 04:23:14.052
6b002114-8d33-4579-9e8e-dc38ae69d517	SHREE CHAMUNDA VIJAY SAW MILL	Ambikanagar,at.karali,Ta. Unja, mehsana, Gujarat.	24AETPP7182D1Z4	215ed277-0f13-40ec-868e-bf9c0699151a	2025-08-14 04:28:08.043	2025-08-14 04:28:08.043
496a5122-3429-4136-ab16-3905035436c2	S K Traders	Rampura, Mehsana	 	215ed277-0f13-40ec-868e-bf9c0699151a	2025-08-25 13:08:12.53	2025-08-25 13:08:12.53
74815b0d-6bee-4e0e-bd6f-b9df475b914c	Narendrasinh Jiluji Chavda	 	 	215ed277-0f13-40ec-868e-bf9c0699151a	2025-08-25 13:32:40.604	2025-08-25 13:32:40.604
5cf2dd21-3759-4d34-b455-9c3b678fef22	JAYVEER FIRE WOOD	Umiya Vijay Saw Mill, Gothava 	 	215ed277-0f13-40ec-868e-bf9c0699151a	2025-09-17 02:49:19.281	2025-09-17 02:49:19.281
89947966-8f2f-405b-a44f-f279054cdb22	Jalaram Saw  Mill	G.I.D.C, Plot No. 7,8, At. Kheralu. Dist. Mehsana. Pin : 384325	24ASSPP8600R1ZU	215ed277-0f13-40ec-868e-bf9c0699151a	2025-10-15 07:16:34.032	2025-10-15 07:16:34.032
514c15d1-430e-4c8a-b4e4-2cdf50f5bdad	Shree Laxminarayan Saw Mill	603/1, Badalpur road, Vadnagar, Dist: Mehsana	24ADBPV7108C1ZU	215ed277-0f13-40ec-868e-bf9c0699151a	2025-10-15 07:21:30.174	2025-10-15 07:21:30.174
03b53e8c-72ef-465f-afe2-5b31c933795b	G S Enterprises	Shop at anujman gali rashmi shop at anujman gali rashmi ward No 5 SH 96Rashmi	08LTIPK2656L1ZY	215ed277-0f13-40ec-868e-bf9c0699151a	2025-10-19 05:34:47.414	2025-10-19 05:34:47.414
fbb6f76e-f550-4bb3-b786-24cbe45b0d2b	RAJADHIRAJ TREDING	Chaudhary vas, Near Pani ni tanki, At Umta	24CPWPP7198R1ZB	215ed277-0f13-40ec-868e-bf9c0699151a	2025-12-21 13:33:58.52	2025-12-21 13:33:58.52
68c72fe2-0cd6-4e2c-b7e8-f42bd76a3edd	New Ashapura Timber Mart 	Saduthala Kamana Road, Visnagar 	24AGWPP5119M1ZP	215ed277-0f13-40ec-868e-bf9c0699151a	2026-01-05 06:40:07.102	2026-01-05 06:40:07.102
\.


--
-- Data for Name: Expenses; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public."Expenses" (id, type, description, amount, "expenseDate", "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: Invoice; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public."Invoice" (id, "invoiceNumber", "organizationId", "userId", "customerId", "billerName", "invoiceType", items, "totalAmount", "vehicalNumber", "gstAmount", "grandTotal", status, "createdAt", "updatedAt", "gstPercentage", uplak) FROM stdin;
dfbc30cd-1e9b-455a-8b5e-9d3e1c2a8f24	10	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	6b002114-8d33-4579-9e8e-dc38ae69d517	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9096, "amount": 111080, "hsnCode": "4407", "quantity": 12.212}]	111080	GJ17Y2720	19994	131074	COMPLETED	2025-08-12 00:00:00	2025-12-21 12:25:05.187	18	
5b572f43-7a5d-4757-ad49-ff1fbe57bbc0	120	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	358185d5-0d27-4a58-a1f8-b7bdcc60302b	\N	CREDIT	[{"name": "WoodenSize", "unit": "QUINTAL", "price": 500, "amount": 100000, "hsnCode": "4407", "quantity": 200}]	100000	RJ14GD9288	18000	118000	COMPLETED	2025-09-18 00:00:00	2025-12-21 12:46:53.391	18	31200
b1955e23-2dbe-46b4-8be7-ccbca22f200b	137	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	358185d5-0d27-4a58-a1f8-b7bdcc60302b	\N	CREDIT	[{"name": "FireWood", "unit": "KG", "price": 425, "amount": 85000, "hsnCode": "4401", "quantity": 200}]	85000	RJ06GA9039	0	85000	COMPLETED	2025-10-11 00:00:00	2025-12-21 12:48:35.824	0	60000
23a0c593-6fb6-4156-947b-c9e462762147	31	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	68c72fe2-0cd6-4e2c-b7e8-f42bd76a3edd	\N	DEBIT	[{"name": "Limdo", "unit": "CBM", "price": 7062, "amount": 40501, "hsnCode": "4407", "quantity": 5.735}]	40501	GJ02AT6857	7290	47791	PENDING	2026-01-05 06:59:58.399	2026-01-05 06:59:58.399	18	\N
b4832b24-11a1-45d6-8c3b-17f8335198b9	30	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	cd64515e-c258-432d-bd8f-2629ddfd4c0e	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 8966, "amount": 82818, "hsnCode": "4407", "quantity": 9.2369}]	82818	GJ27V9377	14907	97725	COMPLETED	2025-03-10 00:00:00	2025-05-09 13:53:32.15	18	\N
664fb256-7d83-4f4c-9a78-c0b18317d9e2	1	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	804083c6-f3fe-4d3c-9c1b-b109e76569d8		DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 10678, "amount": 212289, "hsnCode": "4407", "quantity": 19.881}]	212289	GJ02AT9075	38212	250501	COMPLETED	2025-03-10 00:00:00	2025-05-03 12:12:31.837	18	\N
0997e08b-a328-465d-bcb8-a376c57eb519	1	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	fba9bd5f-a23d-4813-8a14-9e1c40d7eb82	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 9211.2, "amount": 82753, "hsnCode": "4407", "quantity": 8.984}]	82753	GJ02AT1718	14896	97649	COMPLETED	2025-04-04 00:00:00	2025-05-09 13:00:42.631	18	\N
0c127920-562c-4f7e-a16f-35334045e51e	1	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	71ac6a37-0fad-47a0-b477-895e88a68f7d	\N	CREDIT	[{"name": "Wooden Size", "unit": "", "price": 9238, "amount": 45954, "hsnCode": "4407", "quantity": 4.9744}]	45954	GJ13AW3055	8272	54226	COMPLETED	2025-04-03 00:00:00	2025-05-09 13:47:23.588	18	\N
9d8fead2-d016-4486-91ad-20b57ca2284f	5	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	fba9bd5f-a23d-4813-8a14-9e1c40d7eb82	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 9245.11, "amount": 127735, "hsnCode": "4407", "quantity": 13.8165}]	127735	GJ23X5126	22992	150727	COMPLETED	2025-04-30 10:55:02	2025-05-23 15:49:59.413	18	\N
75996043-3753-46c7-8459-29658021dade	65	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 9006, "amount": 28450, "hsnCode": "4407", "quantity": 3.159}]	28450	GJ01HT2076	5121	33571	COMPLETED	2025-03-07 00:00:00	2025-05-09 13:50:51.417	18	\N
aed79c24-97dd-4194-a1d7-512f22700d8f	66	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 9006, "amount": 34574, "hsnCode": "4407", "quantity": 3.839}]	34574	GJ01HT2076	6223	40797	COMPLETED	2025-03-08 12:55:26	2025-05-09 13:51:23.138	18	\N
d648ed06-6e33-49ff-ac55-469a49607388	67	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 9005, "amount": 32832, "hsnCode": "4407", "quantity": 3.646}]	32832	GJ01HT2076	5910	38742	COMPLETED	2025-03-09 12:56:58	2025-05-09 13:51:46.749	18	\N
dbb7059c-9aa1-43f3-837e-ab8140399640	1	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	4a15a7c9-7bd6-4403-b730-8ce40373d509	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 9141, "amount": 115136, "hsnCode": "4407", "quantity": 12.5956}]	115136	GJ09AV2223	20724	135860	COMPLETED	2025-05-07 00:00:00	2025-05-28 05:50:31.112	18	\N
0cccb502-8655-4e43-9189-e0f2e53e29ed	4	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	804083c6-f3fe-4d3c-9c1b-b109e76569d8	\N	DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 10716, "amount": 177961, "hsnCode": "4407", "quantity": 16.607}]	177961	GJ02AT9075	32033	209994	COMPLETED	2025-05-04 12:37:26.6	2025-05-28 05:51:00.965	18	\N
0357b2c4-4da3-4039-8b05-618288ceb163	13	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	b947757b-6c7f-4cca-a6b6-79a16981c050	\N	CREDIT	[{"name": "Wood", "unit": "QUINTAL", "price": 330, "amount": 72600, "hsnCode": "4403", "quantity": 220}]	72600	RJ27GE5980	13068	85668	COMPLETED	2025-05-18 00:00:00	2025-12-21 13:08:19.913	18	50000
1d9fae81-fa9b-4f3c-8455-9b7b330b643c	5	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	804083c6-f3fe-4d3c-9c1b-b109e76569d8	\N	DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 10565, "amount": 151322, "hsnCode": "4407", "quantity": 14.323}]	151322	GJ02AT1718	27238	178560	COMPLETED	2025-05-18 13:47:19.55	2025-06-19 09:13:36.351	18	\N
11393150-204c-49aa-b4b3-a07fcd8ec2a3	2	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 10694.97, "amount": 149302, "hsnCode": "4407", "quantity": 13.96}]	149302	GJ02AT1718	26874	176176	COMPLETED	2025-04-04 10:44:35	2025-06-22 12:41:17.387	18	\N
fffdf487-34cd-4ca2-903d-404f72c9d2e3	348	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 10901, "amount": 147948, "hsnCode": "4407", "quantity": 13.572}]	147948	GJ02AT1718	26631	174579	COMPLETED	2025-04-23 00:00:00	2025-05-28 06:30:08.655	18	\N
15a0b7ba-ad7a-4306-9eec-84e560456f86	6	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 8999, "amount": 41289, "hsnCode": "4407", "quantity": 4.5882}]	41289	GJ01HT2076	7432	48721	COMPLETED	2025-04-23 00:00:00	2025-05-30 11:39:14.886	18	\N
b1173c12-ba4a-4c7f-bebd-6ec63934c867	10	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	fba9bd5f-a23d-4813-8a14-9e1c40d7eb82	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 9186.14, "amount": 95032, "hsnCode": "4407", "quantity": 10.3452}]	95032	GJ02AT9075	17106	112138	COMPLETED	2025-05-26 00:00:00	2025-05-30 11:32:33.596	18	\N
55ccf9f9-d304-433f-a164-813c9c0af772	3	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	804083c6-f3fe-4d3c-9c1b-b109e76569d8		DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 10699.9, "amount": 165527, "hsnCode": "4407", "quantity": 15.47}]	165527	GJ23X5126	29795	195322	COMPLETED	2025-04-30 13:24:43.676	2025-05-31 07:37:25.785	18	\N
cc26b6c3-5af2-42ab-96d3-2786a5e924bf	349	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 10532, "amount": 133018, "hsnCode": "4407", "quantity": 12.6299}]	133018	GJ02ZZ7042	23943	156961	COMPLETED	2025-05-14 00:00:00	2025-07-06 05:52:43.374	18	\N
988cfd30-2cba-4d96-a932-a145e3bec66d	93	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	fbb6f76e-f550-4bb3-b786-24cbe45b0d2b	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9556, "amount": 73667, "hsnCode": "4407", "quantity": 7.709}]	73667	GJ23X5126	13260	86927	COMPLETED	2025-12-21 13:34:56.546	2025-12-23 13:55:21.845	18	
c936abca-f1f9-4399-84ee-67195d26e293	10 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	496a5122-3429-4136-ab16-3905035436c2	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 2.5, "amount": 13913, "hsnCode": "4401", "quantity": 5565}]	13913	GJ02AT8248	0	13913	COMPLETED	2025-12-22 11:37:52.26	2025-12-31 13:22:11.566	0	\N
0a19d918-092f-4543-a126-73e0a94d85bd	7	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 11458, "amount": 218367, "hsnCode": "4407", "quantity": 19.058}]	218367	GJ02AT9075	39306	257673	COMPLETED	2025-06-04 00:00:00	2025-07-28 13:26:35.417	18	\N
1aead43d-462b-4ada-92e3-73c2794ba154	9	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 11350, "amount": 203483, "hsnCode": "4407", "quantity": 17.928}]	203483	GJ02ZZ2363	36627	240110	COMPLETED	2025-06-18 10:24:14.769	2025-08-05 11:32:54.768	18	\N
7bef343c-7c23-4285-8a5d-3628456b24ea	13	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	fba9bd5f-a23d-4813-8a14-9e1c40d7eb82	\N	CREDIT	[{"name": "Size ", "unit": "CBM ", "price": 9514, "amount": 25416, "hsnCode": "4407", "quantity": 2.6714}]	25416	GJ18AV 4193	4575	29991	COMPLETED	2025-06-20 00:00:00	2025-07-18 04:49:53.945	18	\N
63133835-b768-42b1-baa7-15671a0c0e90	12	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	804083c6-f3fe-4d3c-9c1b-b109e76569d8	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11775, "amount": 163437, "hsnCode": "4407", "quantity": 13.88}]	163437	GJ27TT3929	29419	192856	COMPLETED	2025-06-30 11:13:11.746	2025-08-29 10:43:45.138	18	\N
7f6d8eab-a38d-4277-a77a-6d2862fb34df	8	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	fba9bd5f-a23d-4813-8a14-9e1c40d7eb82	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 9377.9, "amount": 115469, "hsnCode": "4407", "quantity": 12.3129}]	115469	GJ02AT1718	20784	136253	COMPLETED	2025-06-08 07:36:59.51	2025-06-13 13:12:01.067	18	\N
62373d6d-d66c-4e0d-89c0-df742f3aad63	16	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	b947757b-6c7f-4cca-a6b6-79a16981c050	\N	CREDIT	[{"name": "Wood", "unit": "QUINTAL", "price": 330, "amount": 72600, "hsnCode": "4403", "quantity": 220}]	72600	RJ27GE5980	13068	85668	COMPLETED	2025-06-13 00:00:00	2025-12-21 13:10:59.957	18	84600
572241c2-1657-46cc-92af-e0052ef19a59	66	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9d33e21c-8018-4cd8-b324-09d70ee38239	\N	CREDIT	[{"name": "WoodenSize", "unit": "Quintal", "price": 396, "amount": 81576, "hsnCode": "4403", "quantity": 206}]	81576	RJ27GG4736	14684	96260	COMPLETED	2025-07-03 00:00:00	2025-12-21 13:13:26.179	18	42600
ba9da1eb-02e8-41e0-9064-03a98c76090d	353	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11388, "amount": 158282, "hsnCode": "4407", "quantity": 13.899}]	158282	GJ17Y2720	28491	186773	COMPLETED	2025-07-16 11:24:34.506	2025-12-21 12:04:23.681	18	\N
c5c52416-34e3-4f1e-a8c0-57fdc82aaf05	56	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	9d33e21c-8018-4cd8-b324-09d70ee38239	\N	CREDIT	[{"name": "WoodenSize", "unit": "Quintal", "price": 326, "amount": 80196, "hsnCode": "4403", "quantity": 246}]	80196	RJ27GD4827	14435	94631	COMPLETED	2025-06-16 00:00:00	2025-12-21 13:18:25.994	18	70000
c6b8dd93-093a-4b65-9712-868dff098460	11	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	fba9bd5f-a23d-4813-8a14-9e1c40d7eb82	\N	CREDIT	[{"name": "Wooden size ", "unit": "CBM ", "price": 9368, "amount": 99797, "hsnCode": "4407", "quantity": 10.653}]	99797	GJ02AT9075	17963	117760	COMPLETED	2025-05-18 00:00:00	2025-06-24 12:12:46.652	18	\N
1b4f8fc6-d276-46ad-bdd9-f14c77cfbfdb	8	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	804083c6-f3fe-4d3c-9c1b-b109e76569d8	\N	DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 11759, "amount": 180113, "hsnCode": "4407", "quantity": 15.317}]	180113	GJ23X5126	32420	212533	COMPLETED	2025-06-06 12:05:12.836	2025-07-02 02:40:42.763	18	\N
b3fb774a-fe92-48c2-9085-5bc938f9705f	2	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	4a15a7c9-7bd6-4403-b730-8ce40373d509	\N	CREDIT	[{"name": "Wooden Size", "unit": "CBM", "price": 9982, "amount": 152890, "hsnCode": "4407", "quantity": 15.3166}]	152890	GJ09AV2223	27520	180410	COMPLETED	2025-06-08 00:00:00	2025-07-02 02:42:42.383	18	\N
ea2a635e-da4a-4ec2-aad2-27925c91f7cd	350	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 10730, "amount": 183966, "hsnCode": "4407", "quantity": 17.145}]	183966	GJ02AT9075	33114	217080	COMPLETED	2025-05-27 00:00:00	2025-07-22 13:53:15.503	18	\N
f73f5e6c-d5fa-4e2f-a668-adf77d66bc62	29	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "WoodenDust", "unit": "KG", "price": 4.5, "amount": 10215, "hsnCode": "4401", "quantity": 2270}]	10215	GJ13AW3055	511	10726	PENDING	2025-12-26 00:00:00	2025-12-27 09:17:36.88	5	
806b469e-edd8-43ae-a1ad-a1ae25125ef2	352	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11368, "amount": 127776, "hsnCode": "4407", "quantity": 11.24}]	127776	GJ02AT1718	23000	150776	COMPLETED	2025-07-06 05:37:33.933	2025-08-05 11:34:18.113	18	\N
5696c65f-4c42-4170-b344-c2f39a878faa	351	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	06d7b938-c2ea-47bd-adc6-b1699cb51899	\N	DEBIT	[{"name": "Wooden Size", "unit": "CBM", "price": 10891, "amount": 29102, "hsnCode": "4407", "quantity": 2.6721}]	29102	GJ18AV4193	5238	34340	COMPLETED	2025-06-20 12:20:35.438	2025-08-11 06:26:51.016	18	\N
0ea4786d-1dac-4783-aefd-1e2f8ee7e320	11	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11502, "amount": 150630, "hsnCode": "4407", "quantity": 13.096}]	150630	GJ08AU7143	27113	177743	COMPLETED	2025-06-26 00:00:00	2025-08-18 11:51:48.128	18	\N
ecb73a55-3d1a-4e4b-81df-733c148ca592	6	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "Wood Dust", "unit": "Quintal", "price": 450, "amount": 13545, "hsnCode": "4401", "quantity": 30.1}]	13545	GJ13AW3055	677	14222	COMPLETED	2025-05-19 00:00:00	2025-11-26 13:54:21.155	5	\N
78c1d0bc-19a2-46a6-aa24-404e31b2cfb4	10	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "WoodenDust", "unit": "KG", "price": 4.5, "amount": 16020, "hsnCode": "4401", "quantity": 3560}]	16020	GJ13AW3055	801	16821	COMPLETED	2025-06-24 00:00:00	2025-07-18 04:21:56.428	5	\N
e242864b-d931-4cb1-b971-24374afbd83c	3	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	4a15a7c9-7bd6-4403-b730-8ce40373d509	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9948, "amount": 138075, "hsnCode": "4407", "quantity": 13.8797}]	138075	GJ09AV2223	24854	162929	COMPLETED	2025-07-08 00:00:00	2025-07-28 13:30:19.553	18	\N
f7a1e6d9-b929-4e92-b8fd-d13feae5e2cd	72	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	9d33e21c-8018-4cd8-b324-09d70ee38239	\N	CREDIT	[{"name": "WoodenSize", "unit": "QUINTAL", "price": 396, "amount": 77616, "hsnCode": "4403", "quantity": 196}]	77616	RJ27GF4736	13971	91587	COMPLETED	2025-07-15 00:00:00	2025-12-21 13:22:50.484	18	55500
bc538e53-09cb-4028-b5c4-d6c680a9d6f1	355	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 10941, "amount": 133611, "hsnCode": "4407", "quantity": 12.212}]	133611	GJ17Y2720	24050	157661	COMPLETED	2025-08-12 00:00:00	2025-08-19 05:12:14.884	18	\N
a8b554a5-29c9-4a72-8915-922d3b18de03	98	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	358185d5-0d27-4a58-a1f8-b7bdcc60302b	\N	CREDIT	[{"name": "WoodenSize", "unit": "Qty.", "price": 350, "amount": 70000, "hsnCode": "4401", "quantity": 200}]	70000	RJ27GE0612	12600	82600	COMPLETED	2025-08-13 00:00:00	2025-12-21 12:40:30.673	18	78625
df40bddc-6bcd-4eec-87c5-0a6c7ea45b8f	354	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11298, "amount": 133441, "hsnCode": "4407", "quantity": 11.811}]	133441	GJ23X5126	24019	157460	COMPLETED	2025-08-03 06:19:34.124	2025-12-21 12:04:35.97	18	\N
029aecfa-b890-4749-ba8e-387a18c93ffc	35	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 8906, "amount": 28045, "hsnCode": "4407", "quantity": 3.149}]	28045	GJ02BT1074	5048	33093	COMPLETED	2025-07-22 00:00:00	2025-08-06 05:51:28.984	18	\N
83ad5eab-9649-43df-88a5-3626a0771a92	34	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 8915, "amount": 25800, "hsnCode": "4407", "quantity": 2.894}]	25800	GJ02BT1074	4644	30444	COMPLETED	2025-07-21 00:00:00	2025-08-06 05:52:11.747	18	\N
88c768b2-c270-42f7-85ad-100f514baee3	21	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 8915, "amount": 38076, "hsnCode": "4407", "quantity": 4.271}]	38076	GJ01HT2076	6854	44930	COMPLETED	2025-06-25 00:00:00	2025-08-06 05:53:21.86	18	\N
9353a881-e3e7-4efc-8a7d-33af53b16d0c	20	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 8915, "amount": 37416, "hsnCode": "4407", "quantity": 4.197}]	37416	GJ01HT2076	6735	44151	COMPLETED	2025-06-23 00:00:00	2025-08-03 09:42:35.315	18	\N
e8462575-48cf-46d2-916f-312b36b552fd	15	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "WoodenDust", "unit": "KG", "price": 4.5, "amount": 15120, "hsnCode": "4401", "quantity": 3360}]	15120	GJ13AW3055	756	15876	COMPLETED	2025-08-05 02:23:25.414	2025-08-27 13:37:42.396	5	\N
05d2de4c-990c-485b-b7e9-61ed082c0350	363	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11462.89, "amount": 169745, "hsnCode": "4407", "quantity": 14.8082}]	169745	GJ23X5126	30554	200299	PENDING	2025-12-28 07:26:20.933	2025-12-28 07:26:20.933	18	\N
74566358-af78-48e4-bae0-3e859dc2cdeb	4	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	4a15a7c9-7bd6-4403-b730-8ce40373d509	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9800, "amount": 76362, "hsnCode": "4407", "quantity": 7.792}]	76362	GJ23X5126	13745	90107	COMPLETED	2025-08-14 00:00:00	2025-08-29 10:22:21.241	18	\N
c791dc48-d15c-405a-b4b4-1d5072a3eea3	14	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "WoodenDust", "unit": "KG", "price": 4.5, "amount": 12150, "hsnCode": "4401", "quantity": 2700}]	12150	GJ13AW3055	608	12758	COMPLETED	2025-07-26 00:00:00	2025-08-18 14:00:14.082	5	\N
47584d96-d1fd-4328-bbbf-a0154120fa97	16	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	804083c6-f3fe-4d3c-9c1b-b109e76569d8	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11459, "amount": 159406, "hsnCode": "4407", "quantity": 13.911}]	159406	GJ17Y2720	28693	188099	COMPLETED	2025-08-10 10:44:42.986	2025-08-29 10:39:17.072	18	\N
bc2f7dd1-e070-4516-8728-1be3625c14f9	13	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11490, "amount": 134077, "hsnCode": "4407", "quantity": 11.669}]	134077	GJ17Y2720	24134	158211	COMPLETED	2025-07-25 04:18:32.076	2025-09-08 07:04:59.118	18	\N
b15de589-ec72-4371-8704-bff698c64550	17	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11628, "amount": 147664, "hsnCode": "4407", "quantity": 12.699}]	147664	GJ23X5126	26580	174244	COMPLETED	2025-08-13 14:17:23.582	2025-09-19 10:20:28.162	18	\N
0997d659-cd74-43ca-91e9-6c8c96c94899	15	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 8913, "amount": 17024, "hsnCode": "4407", "quantity": 1.91}]	17024	GJ01HT2076	3064	20088	COMPLETED	2025-05-14 00:00:00	2025-12-21 11:57:23.119	18	\N
8a826191-93f1-48a5-b4b6-9c2e3c0400b4	95	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	fbb6f76e-f550-4bb3-b786-24cbe45b0d2b	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9586, "amount": 79238, "hsnCode": "4407", "quantity": 8.266}]	79238	GJ23X5126	14263	93501	PENDING	2025-12-28 12:54:27.606	2025-12-28 12:54:27.606	18	\N
2d272b31-95a2-4b45-866f-4c4fbc2cbc30	1	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	71ac6a37-0fad-47a0-b477-895e88a68f7d	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9238, "amount": 45959, "hsnCode": "4407", "quantity": 4.975}]	45959	GJ13AW3055	8273	54232	COMPLETED	2025-04-03 00:00:00	2025-08-14 12:15:00.293	18	\N
a2d13bad-6edd-49bf-98e2-e228444571c3	1	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	fba9bd5f-a23d-4813-8a14-9e1c40d7eb82	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9211, "amount": 82752, "hsnCode": "4407", "quantity": 8.984}]	82752	GJ02AT1718	14895	97647	COMPLETED	2025-04-04 00:00:00	2025-08-14 12:16:35.215	18	\N
db19068d-f69e-415a-bd31-3fe5072d431e	107	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	358185d5-0d27-4a58-a1f8-b7bdcc60302b	\N	CREDIT	[{"name": "WoodLogRound", "unit": "KG", "price": 350, "amount": 70000, "hsnCode": "4401", "quantity": 200}]	70000	RJ27GE0612	12600	82600	COMPLETED	2025-08-24 00:00:00	2025-12-21 12:30:29.5	18	81875
8f2bfcd0-f1a8-4221-ba6f-965aad26c4e8	2	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 10695, "amount": 149302, "hsnCode": "4407", "quantity": 13.96}]	149302	GJ02AT1718 	26874	176176	COMPLETED	2025-04-04 00:00:00	2025-08-14 12:21:09.383	18	\N
4313de85-436a-48d0-9436-ac21ce60a008	113	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	358185d5-0d27-4a58-a1f8-b7bdcc60302b	\N	CREDIT	[{"name": "WoodLogRound", "unit": "KG", "price": 300, "amount": 66000, "hsnCode": "4403", "quantity": 220}]	66000	RJ25GA1772	11880	77880	COMPLETED	2025-09-09 00:00:00	2025-12-21 12:40:57.232	18	70500
66fd4378-0aa9-4109-9883-5af128e6d522	114	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	358185d5-0d27-4a58-a1f8-b7bdcc60302b	\N	CREDIT	[{"name": "FireWood", "unit": "KG", "price": 500, "amount": 100000, "hsnCode": "4401", "quantity": 200}]	100000	RJ27GE0612	0	100000	COMPLETED	2025-09-11 00:00:00	2025-12-21 12:34:16.598	0	47500
96da88a2-dba2-48d1-8af3-297231d1df58	356	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11665, "amount": 197080, "hsnCode": "4407", "quantity": 16.895}]	197080	GJ27TT3929	35474	232554	COMPLETED	2025-08-25 10:39:44.266	2025-12-21 12:08:14.615	18	\N
dc25159e-0ee3-4ee6-be6c-40e7a1a4a19a	3 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	74815b0d-6bee-4e0e-bd6f-b9df475b914c	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 2.5, "amount": 15400, "hsnCode": "4401", "quantity": 6160}, {"name": "FireWood", "unit": "KG", "price": 3.25, "amount": 4485, "hsnCode": "4401", "quantity": 1380}]	19885	GJ09AV2223	0	19885	COMPLETED	2025-07-27 00:00:00	2025-08-28 03:51:16.456	0	\N
84034147-0c8c-4ebc-9d09-6f2bd5c2171b	2 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	74815b0d-6bee-4e0e-bd6f-b9df475b914c	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 2.5, "amount": 51375, "hsnCode": "4401", "quantity": 20550}]	51375	GJ09AV2223	0	51375	COMPLETED	2025-06-24 00:00:00	2025-08-28 03:55:01.914	0	\N
d11fee55-841e-43de-9307-447386a5894e	1 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	496a5122-3429-4136-ab16-3905035436c2	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 2.75, "amount": 12815, "hsnCode": "4401", "quantity": 4660}]	12815	GJ02AT8248	0	12815	COMPLETED	2025-06-15 00:00:00	2025-12-21 11:56:53.718	0	\N
10994e7a-ed36-4fb1-aeff-de647e8832dc	49	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9050, "amount": 37142, "hsnCode": "4407", "quantity": 4.1041}]	37142	GJ02BT1074	6686	43828	COMPLETED	2025-08-29 11:00:18.434	2025-09-09 09:26:30.425	18	\N
cf96939c-660a-46dc-9b25-3f704437d7c7	4 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	74815b0d-6bee-4e0e-bd6f-b9df475b914c	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 2.5, "amount": 7925, "hsnCode": "4401", "quantity": 3170}, {"name": "FireWood", "unit": "KG", "price": 3.25, "amount": 5168, "hsnCode": "4401", "quantity": 1590}]	13093	GJ09AV2223	0	13093	COMPLETED	2025-08-30 12:07:47.266	2025-09-25 13:13:12.875	0	\N
92bf69ac-89a8-4ffc-8260-39f6f78ece8a	5 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	496a5122-3429-4136-ab16-3905035436c2	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 2.5, "amount": 16050, "hsnCode": "4401", "quantity": 6420}]	16050	GJ02AT 8248	0	16050	COMPLETED	2025-09-09 12:34:22.526	2025-09-18 03:15:07.715	0	\N
09c92909-050e-491b-9a3f-de5d910d16b8	20	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "WoodenDust", "unit": "KG", "price": 4.5, "amount": 13590, "hsnCode": "4401", "quantity": 3020}]	13590	GJ13AW3055	680	14270	COMPLETED	2025-09-17 02:42:04.306	2025-10-20 04:59:11.128	5	\N
b306d8f1-5955-40d9-82d1-4c5820bdbe86	18	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "WoodenDust", "unit": "KG", "price": 4.5, "amount": 17415, "hsnCode": "4401", "quantity": 3870}]	17415	GJ13AW3055	871	18286	COMPLETED	2025-08-28 00:00:00	2025-10-20 04:59:53.106	5	\N
3ff948a8-2ee4-46ca-86b9-26d6a0b74a84	357	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11560, "amount": 150326, "hsnCode": "4407", "quantity": 13.004}]	150326	GJ02AT1718	27059	177385	COMPLETED	2025-09-16 11:26:07.998	2025-12-21 12:09:27.661	18	\N
6eecd41b-dc8b-400c-8a3c-b6f00b057aa6	19	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11591, "amount": 141607, "hsnCode": "4407", "quantity": 12.217}]	141607	GJ17Y2720	25489	167096	COMPLETED	2025-09-03 00:00:00	2025-12-21 12:11:55.285	18	\N
a0192846-41f5-4225-9617-dbab37257ea6	144	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	358185d5-0d27-4a58-a1f8-b7bdcc60302b	\N	CREDIT	[{"name": "WoodLogRound", "unit": "KG", "price": 400, "amount": 100000, "hsnCode": "4401", "quantity": 250}]	100000	RJ25GA1772	18000	118000	COMPLETED	2025-10-15 00:00:00	2025-12-21 12:49:39.241	18	51000
6a2fbe5d-52ee-41e0-9ad2-aef4d3448291	7 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	496a5122-3429-4136-ab16-3905035436c2	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 2.5, "amount": 11500, "hsnCode": "4401", "quantity": 4600}]	11500	GJ02AT9088	0	11500	COMPLETED	2025-09-17 00:00:00	2025-09-22 03:20:16.787	0	0
0b04c3c2-8d93-4388-bde1-455f50f538eb	76	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	514c15d1-430e-4c8a-b4e4-2cdf50f5bdad	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9125, "amount": 83320, "hsnCode": "4407", "quantity": 9.131}]	83320	GJ27TT3929	14998	98318	COMPLETED	2025-10-05 00:00:00	2025-12-21 13:26:28.384	18	
5c598399-8062-4bf7-ab12-e9923946b693	358	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11297, "amount": 162211, "hsnCode": "4407", "quantity": 14.3588}]	162211	GJ27TT3929	29198	191409	COMPLETED	2025-10-01 10:58:27.514	2026-01-01 04:12:26.644	18	\N
eb76191a-8db3-47d8-ab5f-6e651430c97c	359	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11869, "amount": 167021, "hsnCode": "4407", "quantity": 14.072}]	167021	GJ35T3839	30064	197085	PENDING	2025-10-03 13:13:42.853	2025-10-03 13:13:42.853	18	\N
04b44f24-a81e-4c8f-97ce-3f4d519afc55	360	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11473, "amount": 201718, "hsnCode": "4407", "quantity": 17.582}]	201718	GJ27TT3929	36309	238027	PENDING	2025-10-14 08:37:14.158	2025-10-14 08:37:14.158	18	\N
5e1d5adb-4262-46d2-ab66-35357af655d2	119	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	03b53e8c-72ef-465f-afe2-5b31c933795b	\N	CREDIT	[{"name": "WoodLogRound", "unit": "KG", "price": 4.6, "amount": 82800, "hsnCode": "4401", "quantity": 18000}]	82800	RJ27GD9662	14904	97704	COMPLETED	2025-10-17 00:00:00	2025-10-19 05:38:48.855	18	12950
76c080b5-69eb-4bed-a5ac-93f7e051ec2b	67	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 8829, "amount": 37479, "hsnCode": "4407", "quantity": 4.245}]	37479	GJ01HT2076	6746	44225	COMPLETED	2025-10-04 00:00:00	2025-10-27 03:10:22.638	18	
775106a9-8a3b-42d7-ac55-2a82b9d67714	21	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11350, "amount": 70506, "hsnCode": "4407", "quantity": 6.212}]	70506	GJ17Y2720	12691	83197	COMPLETED	2025-09-25 00:00:00	2025-11-05 05:04:56.371	18	70000
7be60a38-20ba-4020-a669-f6453c207aad	361	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11768, "amount": 157032, "hsnCode": "4407", "quantity": 13.344}]	157032	GJ17Y2720	28266	185298	PENDING	2025-11-24 10:54:36.372	2025-11-24 10:54:36.372	18	\N
1e7d9a03-eda0-486a-b67f-5dcd56adb56b	25	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11769, "amount": 149937, "hsnCode": "4407", "quantity": 12.74}]	149937	GJ17Y2720	26989	176926	PENDING	2025-10-26 00:00:00	2025-11-24 03:06:44.262	18	
a1ddb02b-d806-498f-b739-3ebdc1638028	150	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	89947966-8f2f-405b-a44f-f279054cdb22	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9480, "amount": 42139, "hsnCode": "4407", "quantity": 4.445}]	42139	GJ27TT3929	7585	49724	COMPLETED	2025-10-05 00:00:00	2025-11-25 03:52:02.703	18	
4d146e25-fd07-4f02-ae36-9e8f1b83dee6	22	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "WoodenDust", "unit": "KG", "price": 4.5, "amount": 7965, "hsnCode": "4401", "quantity": 1770}]	7965	GJ13AW3055	398	8363	COMPLETED	2025-09-29 04:45:36.241	2025-11-30 02:43:29.152	5	\N
d692d166-aa99-493e-a4ec-4849cd69b50e	24	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "WoodenDust", "unit": "KG", "price": 4.5, "amount": 13050, "hsnCode": "4401", "quantity": 2900}]	13050	GJ13AW3055	653	13703	COMPLETED	2025-10-17 05:52:44.888	2025-12-03 12:58:27.957	5	\N
f3aacef4-91eb-4256-9ff9-a2cf85e20bf1	23	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11267, "amount": 179573, "hsnCode": "4407", "quantity": 15.938}]	179573	GJ27TT3929	32323	211896	COMPLETED	2025-10-05 10:55:30.558	2025-12-21 12:12:32.015	18	\N
76c6ae28-230c-4f20-a8ee-12fcc8fecf0f	8 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	496a5122-3429-4136-ab16-3905035436c2	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 6.5, "amount": 16055, "hsnCode": "4401", "quantity": 2470}]	16055	GJ02AT8248	0	16055	COMPLETED	2025-10-15 07:05:17.239	2025-12-21 12:14:45.129	0	\N
87845b14-da49-4700-9fc2-c246bff53922	29	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	fba9bd5f-a23d-4813-8a14-9e1c40d7eb82	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9983.91, "amount": 140490, "hsnCode": "4407", "quantity": 14.0716}]	140490	GJ35T3849	25288	165778	COMPLETED	2025-10-03 00:00:00	2025-12-21 12:16:48.858	18	
815b9b06-eeab-49bd-aadb-3aaab54f0bde	151	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	89947966-8f2f-405b-a44f-f279054cdb22	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9480, "amount": 22386, "hsnCode": "4407", "quantity": 2.3614}]	22386	GJ27TT3929	4029	26415	COMPLETED	2025-10-06 00:00:00	2025-11-25 03:47:17.384	18	
73c5f83f-f414-4576-a2d5-6e4ec33deff1	202	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	358185d5-0d27-4a58-a1f8-b7bdcc60302b	\N	CREDIT	[{"name": "WoodLogRound", "unit": "KG", "price": 250, "amount": 50000, "hsnCode": "4401", "quantity": 200}]	50000	RJ06GA9039	0	50000	COMPLETED	2025-12-02 00:00:00	2025-12-21 12:59:08.026	0	50000
2f698197-2fb8-44af-bc42-38531e8e0565	150	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	89947966-8f2f-405b-a44f-f279054cdb22	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9480, "amount": 42139, "hsnCode": "4407", "quantity": 4.445}]	42139	GJ27TT3929	7585	49724	COMPLETED	2025-10-05 00:00:00	2025-11-25 03:50:32.152	18	
8e1c43b7-6ef4-4a3b-9baf-d4ff3f4ef448	27	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "WoodenDust", "unit": "KG", "price": 4.5, "amount": 11295, "hsnCode": "4401", "quantity": 2510}]	11295	GJ13AW3055	565	11860	PENDING	2025-11-30 02:45:31.713	2025-11-30 02:45:31.713	5	\N
339b9f86-c4fa-4ce1-b1b2-804225524c85	11 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	496a5122-3429-4136-ab16-3905035436c2	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 2.5, "amount": 14500, "hsnCode": "4401", "quantity": 5800}]	14500	GJ02AT8248	0	14500	COMPLETED	2025-12-31 09:27:32.886	2025-12-31 13:24:17.565	0	\N
7434f290-b9d8-4e22-aae1-81fac747687d	30	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11510, "amount": 182217, "hsnCode": "4407", "quantity": 15.8312}]	182217	GJ23X5126	32799	215016	PENDING	2026-01-02 13:42:43.502	2026-01-02 13:42:43.502	18	\N
32fd661d-00cf-4c89-b754-53f679b6bc46	162	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	358185d5-0d27-4a58-a1f8-b7bdcc60302b	\N	CREDIT	[{"name": "WoodLogRound", "unit": "KG", "price": 300, "amount": 60000, "hsnCode": "4401", "quantity": 200}]	60000	RJ27GE0612	0	60000	COMPLETED	2025-11-04 00:00:00	2025-12-04 03:59:16.647	0	
55708867-97a8-493e-b271-15ac4cdcf806	9 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	496a5122-3429-4136-ab16-3905035436c2	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 6.5, "amount": 11440, "hsnCode": "4401", "quantity": 1760}]	11440	GJ02AT8248	0	11440	COMPLETED	2025-11-26 13:21:20.931	2025-12-04 04:00:30.922	0	\N
790535e4-e37e-47d7-91cb-ba1249ee8ed0	28	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	a395f4f8-2990-4cee-9f47-c18879bf11cd	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11449, "amount": 174677, "hsnCode": "4407", "quantity": 15.257}]	174677	GJ17Y2720	31442	206119	PENDING	2025-12-06 04:52:40.926	2025-12-06 04:52:40.926	18	\N
1890f8b7-82e9-4124-98ec-dec603b1f954	362	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11581, "amount": 155487, "hsnCode": "4407", "quantity": 13.426}]	155487	GJ23X5126	27988	183475	PENDING	2025-12-21 06:10:53.644	2025-12-21 06:10:53.644	18	\N
d07e36c9-c93f-44a6-b735-fb0a98a4f9fd	20	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	cd64515e-c258-432d-bd8f-2629ddfd4c0e	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 9809, "amount": 99088, "hsnCode": "4407", "quantity": 10.1017}]	99088	GJ09AV2223	17836	116924	PENDING	2026-01-03 00:00:00	2026-01-08 13:51:02.614	18	
048b1ac6-5694-438e-b02e-be591405ef3f	32	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	62dc0f85-edb0-4857-8055-1d44742ef857	\N	DEBIT	[{"name": "WoodenDust", "unit": "KG", "price": 4.5, "amount": 10395, "hsnCode": "4401", "quantity": 2310}]	10395	GJ13W3055	520	10915	PENDING	2026-01-10 04:54:37.297	2026-01-10 04:54:37.297	5	\N
b7d9b5af-af06-48d9-b247-a2f4309c4ef1	72	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 8990, "amount": 31510, "hsnCode": "4407", "quantity": 3.505}]	31510	GJ01AT2076	5672	37182	PENDING	2025-12-01 00:00:00	2025-12-21 12:20:03.454	18	
e0cffdbc-96b2-4941-8c87-4ac16dd77d9b	73	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	057edbbd-6c9b-4831-9a8a-50f101941ffe	\N	CREDIT	[{"name": "WoodenSize", "unit": "CBM", "price": 8992, "amount": 27426, "hsnCode": "4407", "quantity": 3.05}]	27426	GJ01AT2076	4937	32363	PENDING	2025-12-05 00:00:00	2025-12-21 12:20:10.487	18	
be38fa9e-75ce-43d7-b87b-bbb11ca890ef	12 J	063b3974-e1fe-4025-b35c-1e39407eb9cc	215ed277-0f13-40ec-868e-bf9c0699151a	5cf2dd21-3759-4d34-b455-9c3b678fef22	\N	DEBIT	[{"name": "FireWood", "unit": "KG", "price": 3, "amount": 19995, "hsnCode": "4401", "quantity": 6665}]	19995	GJ08Z2159	0	19995	COMPLETED	2026-01-10 05:13:31.163	2026-01-10 05:15:57.114	0	\N
094acc90-2f67-455d-b769-4692d19a780d	364	94c3b2f3-ab34-4f77-80ed-a132c7e167fb	215ed277-0f13-40ec-868e-bf9c0699151a	9ce9028c-ae02-40be-87dc-420cca36f7d5	\N	DEBIT	[{"name": "WoodenSize", "unit": "CBM", "price": 11891, "amount": 170965, "hsnCode": "4407", "quantity": 14.3777}]	170965	GJ23X5126	30774	201739	PENDING	2026-01-12 00:00:00	2026-01-11 17:08:47.068	18	
\.


--
-- Data for Name: Organization; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public."Organization" (id, name, "gstNumber", logo, address, "bankName", "accountNumber", "ifscCode", policy, "userId", "invoiceCount", "createdAt", "updatedAt", "fireWoodInvoiceCount") FROM stdin;
063b3974-e1fe-4025-b35c-1e39407eb9cc	SHRI RAM TRADERS	24ATKPM9310Q1Z4	https://izukphsduwrobkseexqp.supabase.co/storage/v1/object/public/images/images/SRT%20logo.png1745584731198	Visnagar-Kamana road,Saduthala	BOB	01540200001122	BARB0VISNAG	\N	215ed277-0f13-40ec-868e-bf9c0699151a	32	2025-04-25 12:38:53.332	2026-01-10 05:13:31.401	12
94c3b2f3-ab34-4f77-80ed-a132c7e167fb	RAM VIJAY SAW MILL	24ABLPM3490L2Z8	https://izukphsduwrobkseexqp.supabase.co/storage/v1/object/public/images/images/RVSMLogo.png1748412061865	Vijapur road, Visnagar	HDFC	50200085623633	HDFC0000532	\N	215ed277-0f13-40ec-868e-bf9c0699151a	364	2025-05-28 06:01:04.349	2026-01-11 17:08:15.205	0
\.


--
-- Data for Name: PaymentLog; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public."PaymentLog" (id, "invoiceId", amount, note, "paymentDate", "createdAt", "updatedAt", "creditBillsId") FROM stdin;
bcce800c-d36a-4b08-8270-db7d442e0ba0	664fb256-7d83-4f4c-9a78-c0b18317d9e2	250501		2025-04-05 00:00:00	2025-04-28 11:47:19.924	2025-04-28 11:47:19.924	\N
4728d60e-ca1d-45cb-bdad-dbd529885287	0997e08b-a328-465d-bcb8-a376c57eb519	97649	NEFT BoB	2025-04-27 00:00:00	2025-05-09 13:00:42.181	2025-05-09 13:00:42.181	\N
2c2e75c4-1a63-49fa-9e00-5040a448a982	0c127920-562c-4f7e-a16f-35334045e51e	54226	NEFT Bob	2025-05-04 00:00:00	2025-05-09 13:47:23.149	2025-05-09 13:47:23.149	\N
0104b36f-debf-4a36-908a-54bc24f097a3	75996043-3753-46c7-8459-29658021dade	33571	NEFT BOB	2025-04-08 00:00:00	2025-05-09 13:50:50.965	2025-05-09 13:50:50.965	\N
56c42b19-785a-47f3-9d35-21fdc64b8a59	aed79c24-97dd-4194-a1d7-512f22700d8f	40797	NEFT BOB	2025-04-08 00:00:00	2025-05-09 13:51:22.693	2025-05-09 13:51:22.693	\N
fc5db661-7efa-4abb-9fa6-03dd65b027d2	d648ed06-6e33-49ff-ac55-469a49607388	38742	NEFT BOB	2025-04-08 00:00:00	2025-05-09 13:51:46.315	2025-05-09 13:51:46.315	\N
a921d4f0-b1e2-4e66-91c5-bfafe341f53a	b4832b24-11a1-45d6-8c3b-17f8335198b9	97725	NEFT BOB	2025-04-06 00:00:00	2025-05-09 13:53:31.928	2025-05-09 13:53:31.928	\N
0980ff77-0390-4ee2-8197-1517ede3ca99	9d8fead2-d016-4486-91ad-20b57ca2284f	99727	NEFT BOB	2025-05-20 00:00:00	2025-05-23 06:03:57.922	2025-05-23 06:03:57.922	\N
0794f50a-2db9-4ce2-9068-dadcea353a2d	9d8fead2-d016-4486-91ad-20b57ca2284f	51000	NEFT Bob	2025-05-23 00:00:00	2025-05-23 15:49:58.971	2025-05-23 15:49:58.971	\N
4187126d-185e-4eee-98b8-b47e82a21248	dbb7059c-9aa1-43f3-837e-ab8140399640	135860	NEFT BOB	2025-05-25 00:00:00	2025-05-28 05:50:30.919	2025-05-28 05:50:30.919	\N
9d0f59de-2fe6-4b4a-8cd7-c295456a1cda	0cccb502-8655-4e43-9189-e0f2e53e29ed	209994		2025-05-27 00:00:00	2025-05-28 05:51:00.756	2025-05-28 05:51:00.756	\N
0a6d80a1-e49a-4a28-b660-56397dec4cb5	fffdf487-34cd-4ca2-903d-404f72c9d2e3	174579		2025-04-26 00:00:00	2025-05-28 06:30:08.453	2025-05-28 06:30:08.453	\N
c03d60e2-676a-43fd-b637-66b12e8068e9	b1173c12-ba4a-4c7f-bebd-6ec63934c867	50000	NEFT HDFC	2025-05-25 00:00:00	2025-05-28 06:39:09.57	2025-05-28 06:39:09.57	\N
eed45b89-24f2-436d-a86d-0d89fdb489ee	b1173c12-ba4a-4c7f-bebd-6ec63934c867	62138	NEFT HDFC	2025-05-30 00:00:00	2025-05-30 11:32:33.12	2025-05-30 11:32:33.12	\N
101d7b4b-9eca-44aa-8b60-4f390fe1c9c4	15a0b7ba-ad7a-4306-9eec-84e560456f86	48721	NEFT HDFC	2025-05-30 00:00:00	2025-05-30 11:39:14.433	2025-05-30 11:39:14.433	\N
0026d514-3c1e-4e0e-b9bc-8f9ed3388c15	55ccf9f9-d304-433f-a164-813c9c0af772	195322	NEFT BOB 	2025-05-18 00:00:00	2025-05-31 07:37:25.185	2025-05-31 07:37:25.185	\N
b22ce6c7-12a5-4f74-ab49-fa9b4e86c483	ecb73a55-3d1a-4e4b-81df-733c148ca592	14220	NEFT BOB 	2025-05-26 00:00:00	2025-06-04 09:11:31.793	2025-06-04 09:11:31.793	\N
a634e984-8497-4973-96bf-931ae4677560	7f6d8eab-a38d-4277-a77a-6d2862fb34df	136253	NEFT BOB	2025-06-13 00:00:00	2025-06-13 13:12:00.39	2025-06-13 13:12:00.39	\N
68bfa081-b7c7-4ec4-835d-fe2974a12ba0	0357b2c4-4da3-4039-8b05-618288ceb163	85668		2025-06-15 00:00:00	2025-06-15 06:14:10.974	2025-06-15 06:14:10.974	\N
e5bb5f3d-192b-41b1-8196-edc860746a31	1d9fae81-fa9b-4f3c-8455-9b7b330b643c	178560	NEFT BOB 	2025-06-16 00:00:00	2025-06-19 09:13:35.89	2025-06-19 09:13:35.89	\N
3ee3187d-c62f-4fcb-8692-78d6952c9ad2	62373d6d-d66c-4e0d-89c0-df742f3aad63	85668		2025-06-16 00:00:00	2025-06-22 12:25:20.677	2025-06-22 12:25:20.677	\N
ebc9991b-6c79-4863-986f-0a508069d389	11393150-204c-49aa-b4b3-a07fcd8ec2a3	176176	NEFT PAYMENT BOB CHUKTE 	2025-06-20 00:00:00	2025-06-22 12:41:16.944	2025-06-22 12:41:16.944	\N
ac7ce934-34fe-44c2-b093-f295f9171dcb	c6b8dd93-093a-4b65-9712-868dff098460	117760	NEFT HDFC 	2025-06-24 00:00:00	2025-06-24 12:12:46.2	2025-06-24 12:12:46.2	\N
0a8c5bef-124a-4ab5-8ddf-32ac524a9e47	1b4f8fc6-d276-46ad-bdd9-f14c77cfbfdb	212533	NEFT BOB 	2025-07-01 00:00:00	2025-07-02 02:40:42.297	2025-07-02 02:40:42.297	\N
cf181cd8-4d6d-4a8f-ad01-9415ff079b60	b3fb774a-fe92-48c2-9085-5bc938f9705f	180410	Bill no 2 chukte \nNEFT BOB 	2025-07-02 00:00:00	2025-07-02 02:42:41.954	2025-07-02 02:42:41.954	\N
e59dfffc-d4d3-403e-9070-805385d207ae	cc26b6c3-5af2-42ab-96d3-2786a5e924bf	156961	NEFT HDFC	2025-07-05 00:00:00	2025-07-06 05:52:42.936	2025-07-06 05:52:42.936	\N
aad48e9f-e38f-4efa-9ddb-8c7a48b0bf9c	572241c2-1657-46cc-92af-e0052ef19a59	96260	NEFT HDFC Bank	2025-07-06 00:00:00	2025-07-06 12:50:17.497	2025-07-06 12:50:17.497	\N
3a33a77b-b8c6-42c4-863c-a66ab7365f22	c5c52416-34e3-4f1e-a8c0-57fdc82aaf05	94631	NEFT BOB	2025-06-20 00:00:00	2025-07-06 13:03:03.592	2025-07-06 13:03:03.592	\N
737af8dd-cbd1-41e6-b331-1735de8ac257	78c1d0bc-19a2-46a6-aa24-404e31b2cfb4	16821	NEFT PAYMENT BOB CHUKTE 	2025-07-17 00:00:00	2025-07-18 04:21:55.991	2025-07-18 04:21:55.991	\N
a79f16df-4681-4aa8-af2a-8b5c7830cc94	7bef343c-7c23-4285-8a5d-3628456b24ea	29991	NEFT PAYMENT HDFC BANK CHUKTE 	2025-07-18 00:00:00	2025-07-18 04:49:53.503	2025-07-18 04:49:53.503	\N
e9a8f361-a77e-4231-8817-b177624084b5	0a19d918-092f-4543-a126-73e0a94d85bd	157673	NEFT BOB	2025-07-18 00:00:00	2025-07-18 11:18:56.119	2025-07-18 11:18:56.119	\N
91b3c8c1-1d40-42a5-93b4-cc0ab0eeaaf3	f7a1e6d9-b929-4e92-b8fd-d13feae5e2cd	91587	GOOGLE PAY BOB	2025-07-14 00:00:00	2025-07-18 11:25:58.913	2025-07-18 11:25:58.913	\N
3f012117-a3fc-44aa-a097-56a34b317b05	ea2a635e-da4a-4ec2-aad2-27925c91f7cd	217080	NEFT HDFC	2025-07-22 00:00:00	2025-07-22 13:53:15.066	2025-07-22 13:53:15.066	\N
d00f9d0d-27d9-47c1-aa71-3d6254a0ce5a	0a19d918-092f-4543-a126-73e0a94d85bd	100000	NEFT BOB	2025-07-28 00:00:00	2025-07-28 13:26:34.975	2025-07-28 13:26:34.975	\N
13bb49ab-d41b-41fd-8348-a898629f0b20	e242864b-d931-4cb1-b971-24374afbd83c	99929	NEFT PAYMENT BOB BILL No 3 Pete 	2025-07-18 00:00:00	2025-07-28 13:29:31.079	2025-07-28 13:29:31.079	\N
72ae3a9c-494a-4ffc-b977-3ac3a5b78a72	e242864b-d931-4cb1-b971-24374afbd83c	63000	NEFT PAYMENT BOB BILL NO 3 CHUKTE 	2025-07-28 00:00:00	2025-07-28 13:30:19.334	2025-07-28 13:30:19.334	\N
7472be11-6466-4b66-ad62-e0b4e7ba0a9c	9353a881-e3e7-4efc-8a7d-33af53b16d0c	44151	Cash	2025-06-17 00:00:00	2025-08-03 09:42:34.872	2025-08-03 09:42:34.872	\N
a7140ae5-f9f5-47fb-88bb-4956086b48b3	88c768b2-c270-42f7-85ad-100f514baee3	15691	cash	2025-06-17 00:00:00	2025-08-03 09:43:59.55	2025-08-03 09:43:59.55	\N
0235e347-2aa0-4bbf-bd07-ef349629ecb2	1aead43d-462b-4ada-92e3-73c2794ba154	240110	Neft bob	2025-08-05 00:00:00	2025-08-05 11:32:54.321	2025-08-05 11:32:54.321	\N
e0074fa0-82b8-4158-9b8e-3311f7a202e6	806b469e-edd8-43ae-a1ad-a1ae25125ef2	150776	Neft hdfc	2025-08-05 00:00:00	2025-08-05 11:34:17.846	2025-08-05 11:34:17.846	\N
1e8e274b-9bbb-4669-b9f5-1e1eca791336	029aecfa-b890-4749-ba8e-387a18c93ffc	33093	Neft hdfc	2025-08-05 00:00:00	2025-08-06 05:51:28.539	2025-08-06 05:51:28.539	\N
be2f69d8-c6c0-48e2-b7e4-b3598496b15b	83ad5eab-9649-43df-88a5-3626a0771a92	30444	Neft hdfc	2025-08-05 00:00:00	2025-08-06 05:52:11.306	2025-08-06 05:52:11.306	\N
f7843870-163e-4541-b3e0-9dc3908b09bd	88c768b2-c270-42f7-85ad-100f514baee3	29239	Neft hdfc all payment	2025-08-04 00:00:00	2025-08-06 05:53:21.639	2025-08-06 05:53:21.639	\N
c37839e5-2c90-4d0c-8770-cc457c8b45f0	5696c65f-4c42-4170-b344-c2f39a878faa	34340	NEFT HDFC BANK CHUKTE 	2025-07-29 00:00:00	2025-08-11 06:26:50.557	2025-08-11 06:26:50.557	\N
7411c28f-5d46-4af7-8bfb-00a63fa0536c	a8b554a5-29c9-4a72-8915-922d3b18de03	70000	Google pay BOB BILL NO 98 Pete 	2025-08-13 00:00:00	2025-08-14 04:48:56.038	2025-08-14 04:48:56.038	\N
addb0cc3-281f-4735-907e-a4396a999538	2d272b31-95a2-4b45-866f-4c4fbc2cbc30	54232	NEFT BOB CHUKTE 	2025-05-04 00:00:00	2025-08-14 12:14:59.803	2025-08-14 12:14:59.803	\N
154c7af4-4398-4fbd-a6c8-d71361f1f7f8	a2d13bad-6edd-49bf-98e2-e228444571c3	97647	NEFT BOB CHUKTE 	2025-04-27 00:00:00	2025-08-14 12:16:34.988	2025-08-14 12:16:34.988	\N
b21359f6-c97e-4973-8213-5d0418d04169	8f2bfcd0-f1a8-4221-ba6f-965aad26c4e8	176176	NEFT BOB CHUKTE 	2025-06-19 00:00:00	2025-08-14 12:21:08.932	2025-08-14 12:21:08.932	\N
a37469e9-ffd8-4e31-97b1-be84ae29af1c	0ea4786d-1dac-4783-aefd-1e2f8ee7e320	177743	NEFT payment successfull BOB 	2025-08-18 00:00:00	2025-08-18 11:51:47.684	2025-08-18 11:51:47.684	\N
b73599f8-b2db-44e8-b11c-616a08aaabed	c791dc48-d15c-405a-b4b4-1d5072a3eea3	12758	NEFT BOB CHUKTE 	2025-08-15 00:00:00	2025-08-18 14:00:13.636	2025-08-18 14:00:13.636	\N
98302fa0-e7b8-4d07-aea4-181abd599a4e	bc538e53-09cb-4028-b5c4-d6c680a9d6f1	157661	 NEFT PAYMENT HDFC 355 CHUKTE 	2025-08-19 00:00:00	2025-08-19 05:12:14.428	2025-08-19 05:12:14.428	\N
2b657e52-e4d1-4872-bcf2-763d008e5dd7	e8462575-48cf-46d2-916f-312b36b552fd	15876	Imps bob	2025-08-27 00:00:00	2025-08-27 13:37:41.952	2025-08-27 13:37:41.952	\N
a4099675-f87d-4abc-9e47-1c87d7040365	dc25159e-0ee3-4ee6-be6c-40e7a1a4a19a	19885	 BILL 3-J Chukte NEFT BOB 	2025-08-26 00:00:00	2025-08-28 03:51:15.988	2025-08-28 03:51:15.988	\N
178f26c1-c6a8-49c0-a5aa-fd2161469fab	84034147-0c8c-4ebc-9d09-6f2bd5c2171b	50000	Bill no 2-J Chukte NEFT BOB 	2025-07-16 00:00:00	2025-08-28 03:54:11.056	2025-08-28 03:54:11.056	\N
1d469293-25de-4d90-88e6-f06f948b4575	84034147-0c8c-4ebc-9d09-6f2bd5c2171b	1375	Bill 2-J Chukte NEFT BOB 	2025-08-26 00:00:00	2025-08-28 03:55:01.685	2025-08-28 03:55:01.685	\N
a599a40b-432c-4e5b-8e17-30756a9f917e	74566358-af78-48e4-bae0-3e859dc2cdeb	90107	Google pay BOB	2025-08-29 00:00:00	2025-08-29 10:22:20.791	2025-08-29 10:22:20.791	\N
a401de14-52c3-4af6-b1f9-89e65aed6002	47584d96-d1fd-4328-bbbf-a0154120fa97	188099	Neft BOB	2025-08-29 00:00:00	2025-08-29 10:39:16.627	2025-08-29 10:39:16.627	\N
4bf592f9-7e72-4fb6-a44d-30f58d4dd47f	63133835-b768-42b1-baa7-15671a0c0e90	160824	Neft BOB 	2025-08-03 00:00:00	2025-08-29 10:41:23.151	2025-08-29 10:41:23.151	\N
e3a2f8e8-2172-4e41-b8aa-f4afcc5d1ac6	63133835-b768-42b1-baa7-15671a0c0e90	32032	Neft BOB 	2025-08-29 00:00:00	2025-08-29 10:43:44.709	2025-08-29 10:43:44.709	\N
f06dc181-ba75-4a4e-87d0-4c8cc307733e	bc2f7dd1-e070-4516-8728-1be3625c14f9	158211	NEFT PAYMENT BOB CHUKTE 	2025-09-08 00:00:00	2025-09-08 07:04:58.675	2025-09-08 07:04:58.675	\N
c03afffd-30fb-48a2-af91-87de1e143f08	10994e7a-ed36-4fb1-aeff-de647e8832dc	43828	NEFT PAYMENT HDFC Chukte 	2025-09-09 00:00:00	2025-09-09 09:26:29.972	2025-09-09 09:26:29.972	\N
c931b863-e1d9-4d8f-842e-7a414e7961d4	6a2fbe5d-52ee-41e0-9ad2-aef4d3448291	11500	NEFT BOB	2025-09-17 00:00:00	2025-09-17 12:48:19.762	2025-09-17 12:48:19.762	\N
0d35ad0f-4bfa-4624-85f3-99967652df67	66fd4378-0aa9-4109-9883-5af128e6d522	100000	Google pay BOB Bank Chukte 	2025-09-11 00:00:00	2025-09-18 03:13:33.492	2025-09-18 03:13:33.492	\N
cab5bdd7-dae6-4a2b-ad98-0f8aa211ad5d	92bf69ac-89a8-4ffc-8260-39f6f78ece8a	16050	Google pay BOB Bank Chukte 	2025-09-10 00:00:00	2025-09-18 03:15:07.254	2025-09-18 03:15:07.254	\N
d9a2fcaf-bd43-4573-8e09-c9bad7cf3b0d	4313de85-436a-48d0-9436-ac21ce60a008	77880	Google pay BOB Bank Chukte 	2025-09-10 00:00:00	2025-09-18 03:18:30.915	2025-09-18 03:18:30.915	\N
43c62080-6000-4632-94a7-a784602dfc36	db19068d-f69e-415a-bd31-3fe5072d431e	82600	Google pay BOB Bank Chukte 	2025-08-25 00:00:00	2025-09-18 03:20:45.644	2025-09-18 03:20:45.644	\N
1160888e-ea86-4300-8023-e79eea8ff5cd	b15de589-ec72-4371-8704-bff698c64550	174244	NEFT payment BOB Bank 	2025-09-18 00:00:00	2025-09-19 10:20:27.717	2025-09-19 10:20:27.717	\N
c073301e-899e-43ae-ad52-9a61203b2129	cf96939c-660a-46dc-9b25-3f704437d7c7	13093	NEFT PAYMENT BOB CHUKTE 	2025-09-23 00:00:00	2025-09-25 13:13:12.344	2025-09-25 13:13:12.344	\N
2cddf7a6-3528-40d5-af5f-29205cc68196	ba9da1eb-02e8-41e0-9064-03a98c76090d	50000		2025-09-20 00:00:00	2025-09-25 13:49:48.159	2025-09-25 13:49:48.159	\N
9c917403-4e86-4b23-8cae-31c592e05333	b1955e23-2dbe-46b4-8be7-ccbca22f200b	60000	cash	2025-10-10 00:00:00	2025-10-15 07:31:29.681	2025-10-15 07:31:29.681	\N
96127ef4-8a64-442c-9ee9-afff7186dcfe	b1955e23-2dbe-46b4-8be7-ccbca22f200b	85000	gogle pay bob	2025-10-15 00:00:00	2025-10-15 07:31:45.932	2025-10-15 07:31:45.932	\N
6aa44d8a-f4b4-4058-a99b-17e02e642e89	5e1d5adb-4262-46d2-ab66-35357af655d2	12950	cash	2025-10-17 00:00:00	2025-10-19 05:38:23.319	2025-10-19 05:38:23.319	\N
c8aa1cfd-d7f7-4fb6-814c-e1172f01fc1a	5e1d5adb-4262-46d2-ab66-35357af655d2	97704	google pay hdfc	2025-10-17 00:00:00	2025-10-19 05:38:48.642	2025-10-19 05:38:48.642	\N
82b71637-a9c0-4464-9060-0ab50aa4c2bf	a0192846-41f5-4225-9617-dbab37257ea6	51000	Cash	2025-10-17 00:00:00	2025-10-19 05:39:34.784	2025-10-19 05:39:34.784	\N
0247bdbf-bda7-427d-80b3-e5eb7bac42ed	a0192846-41f5-4225-9617-dbab37257ea6	99000	google pay bob	2025-10-17 00:00:00	2025-10-19 05:39:57.973	2025-10-19 05:39:57.973	\N
d98572d1-d3e1-4712-8510-e6888b1c5d50	09c92909-050e-491b-9a3f-de5d910d16b8	14270	Imps bob	2025-10-19 00:00:00	2025-10-20 04:59:10.656	2025-10-20 04:59:10.656	\N
404dde86-bb98-4a86-933b-5deb82834bc3	b306d8f1-5955-40d9-82d1-4c5820bdbe86	18286	Imps BOB	2025-10-19 00:00:00	2025-10-20 04:59:52.67	2025-10-20 04:59:52.67	\N
b8e7f249-232f-4aec-b18e-f052c0838f6f	76c080b5-69eb-4bed-a5ac-93f7e051ec2b	44225	Google pay BOB Bank Shri Ram Traders 	2025-10-20 00:00:00	2025-10-27 03:10:22.197	2025-10-27 03:10:22.197	\N
20510cbe-e322-45d2-bee9-46d62cf25153	775106a9-8a3b-42d7-ac55-2a82b9d67714	83197	NEFT PAYMENT BOB CHUKTE 	2025-10-30 00:00:00	2025-11-05 05:03:44.408	2025-11-05 05:03:44.408	\N
dc71b6d4-20cb-4e32-adf3-41d852041cd6	775106a9-8a3b-42d7-ac55-2a82b9d67714	70000		2025-11-05 00:00:00	2025-11-05 05:04:56.153	2025-11-05 05:04:56.153	\N
3d357284-d282-4c50-a3d0-fd0c639b0e6f	815b9b06-eeab-49bd-aadb-3aaab54f0bde	26415	Google pay HDFC Bank 	2025-10-18 00:00:00	2025-11-25 03:47:16.892	2025-11-25 03:47:16.892	\N
d0868d9f-9279-48e9-94e6-b4b8b3c16278	2f698197-2fb8-44af-bc42-38531e8e0565	49724	Google pay HDFC Bank 	2025-10-18 00:00:00	2025-11-25 03:50:31.708	2025-11-25 03:50:31.708	\N
ccee16f1-b676-4d9a-be28-8c2884096bdc	a1ddb02b-d806-498f-b739-3ebdc1638028	49724	Google pay HDFC Bank 	2025-10-18 00:00:00	2025-11-25 03:52:02.255	2025-11-25 03:52:02.255	\N
c30517b9-f2cc-4b49-983b-f8c2260d6f40	ecb73a55-3d1a-4e4b-81df-733c148ca592	2		2025-11-26 00:00:00	2025-11-26 13:54:20.648	2025-11-26 13:54:20.648	\N
27fd26e4-2925-440c-85f6-bc39a2fe7560	4d146e25-fd07-4f02-ae36-9e8f1b83dee6	8363	IMPS બિલ પેમેન્ટ 22ચુકતે BOB BANK 	2025-11-29 00:00:00	2025-11-30 02:43:28.721	2025-11-30 02:43:28.721	\N
f112cad5-5e41-435d-b43f-d38a034ddc1a	d692d166-aa99-493e-a4ec-4849cd69b50e	13703	NEFT payment Bill no 24 BOB Bank 	2025-12-03 00:00:00	2025-12-03 12:58:27.471	2025-12-03 12:58:27.471	\N
399ba7e9-f98a-4055-a8f6-5d23dca91207	32fd661d-00cf-4c89-b754-53f679b6bc46	60000	Google pay BOB Bank Chukte 	2025-12-03 00:00:00	2025-12-04 03:59:16.207	2025-12-04 03:59:16.207	\N
b4197ed7-8689-460d-9081-e0e488626d1e	55708867-97a8-493e-b271-15ac4cdcf806	11440	UPI PAYMENT BOB BANK CHUKTE 	2025-12-03 00:00:00	2025-12-04 04:00:30.477	2025-12-04 04:00:30.477	\N
d530dc3f-a976-4b0f-a673-958ad5f842e3	d11fee55-841e-43de-9307-447386a5894e	12815	NEFT BOB	2025-06-15 00:00:00	2025-12-21 11:56:53.515	2025-12-21 11:56:53.515	\N
41859810-2f0b-467c-8812-cb0044e9f839	0997d659-cd74-43ca-91e9-6c8c96c94899	20088	NEFT HDFC	2025-06-15 00:00:00	2025-12-21 11:57:23.003	2025-12-21 11:57:23.003	\N
8c2b9a3e-56ca-452c-96fb-e7e77ab8980e	ba9da1eb-02e8-41e0-9064-03a98c76090d	136773	NEFT HDFC	2025-09-30 00:00:00	2025-12-21 12:04:23.567	2025-12-21 12:04:23.567	\N
974d5d8e-a81b-495b-a95d-c7e0c5ea8b26	df40bddc-6bcd-4eec-87c5-0a6c7ea45b8f	157460	NEFT HDFC	2025-09-30 00:00:00	2025-12-21 12:04:35.766	2025-12-21 12:04:35.766	\N
00e44cd7-f74b-4989-930c-b25cf7b749ea	96da88a2-dba2-48d1-8af3-297231d1df58	232554	NEFT HDFC	2025-10-17 00:00:00	2025-12-21 12:08:14.41	2025-12-21 12:08:14.41	\N
00851bcc-1660-4313-a2d2-5eb10f8aad95	3ff948a8-2ee4-46ca-86b9-26d6a0b74a84	100000	NEFT HDFC	2025-11-25 00:00:00	2025-12-21 12:09:08.401	2025-12-21 12:09:08.401	\N
46c40e62-0dbd-4cc3-b94f-ff758694e281	3ff948a8-2ee4-46ca-86b9-26d6a0b74a84	77385	NEFT HDFC	2025-12-20 00:00:00	2025-12-21 12:09:27.457	2025-12-21 12:09:27.457	\N
252305a6-490a-433b-906a-138f7fe6627c	6eecd41b-dc8b-400c-8a3c-b6f00b057aa6	167096	NEFT BOB	2025-10-15 00:00:00	2025-12-21 12:11:55.081	2025-12-21 12:11:55.081	\N
2ad01ef1-74ed-4720-b8b0-3dd05cb566e2	f3aacef4-91eb-4256-9ff9-a2cf85e20bf1	211896	NEFT BOB	2025-12-05 00:00:00	2025-12-21 12:12:31.709	2025-12-21 12:12:31.709	\N
559c9e85-0158-464f-8d61-79db5504c29b	76c6ae28-230c-4f20-a8ee-12fcc8fecf0f	16055	Google pay BOB	2025-10-15 00:00:00	2025-12-21 12:14:45.004	2025-12-21 12:14:45.004	\N
2e4ced92-5556-4d85-b18b-468d2ca27804	87845b14-da49-4700-9fc2-c246bff53922	100000	GPAY BOB	2025-12-06 00:00:00	2025-12-21 12:16:31.757	2025-12-21 12:16:31.757	\N
59523ee7-9fb5-44b5-b95d-5f024d93452e	87845b14-da49-4700-9fc2-c246bff53922	65778	GPAY BOB	2025-12-07 00:00:00	2025-12-21 12:16:48.75	2025-12-21 12:16:48.75	\N
d5272d66-ca53-4f2e-8172-29988dfb0cf3	dfbc30cd-1e9b-455a-8b5e-9d3e1c2a8f24	50000	NEFT HDFC	2025-08-23 00:00:00	2025-12-21 12:24:14.54	2025-12-21 12:24:14.54	\N
e87fb18b-410d-4649-b47f-c1074fab634b	dfbc30cd-1e9b-455a-8b5e-9d3e1c2a8f24	81074	NEFT HDFC	2025-08-24 00:00:00	2025-12-21 12:24:44.536	2025-12-21 12:24:44.536	\N
ae392ad2-b6aa-43e1-8bcc-c40b873b7ab4	db19068d-f69e-415a-bd31-3fe5072d431e	81875	CASH	2025-08-25 00:00:00	2025-12-21 12:30:29.295	2025-12-21 12:30:29.295	\N
6a732380-02b0-4145-bd41-13b7157cf28d	4313de85-436a-48d0-9436-ac21ce60a008	66000	GPAY	2025-09-10 00:00:00	2025-12-21 12:32:58.169	2025-12-21 12:32:58.169	\N
cce7b352-d106-40b7-82b2-234c07d86751	66fd4378-0aa9-4109-9883-5af128e6d522	47500	GPAY	2025-09-11 00:00:00	2025-12-21 12:34:16.394	2025-12-21 12:34:16.394	\N
41871305-0f37-4e23-93d7-6c875d6fb9a9	a8b554a5-29c9-4a72-8915-922d3b18de03	12500	GPAY	2025-08-13 00:00:00	2025-12-21 12:37:16.042	2025-12-21 12:37:16.042	\N
3b79d382-2c08-4f39-9fc9-cdb78bca2c95	a8b554a5-29c9-4a72-8915-922d3b18de03	78725	GPAY	2025-08-13 00:00:00	2025-12-21 12:40:29.684	2025-12-21 12:40:29.684	\N
8242ab28-5708-4330-85e4-477ab9612bf3	4313de85-436a-48d0-9436-ac21ce60a008	4500	GPAY	2025-09-10 00:00:00	2025-12-21 12:40:56.344	2025-12-21 12:40:56.344	\N
27b8b712-217e-4c51-aa1d-cccbf4621cc7	5b572f43-7a5d-4757-ad49-ff1fbe57bbc0	18000	NEFT BOB	2025-09-19 00:00:00	2025-12-21 12:45:11.293	2025-12-21 12:45:11.293	\N
c835712e-b0c6-454d-a49a-b0d37bf28b05	5b572f43-7a5d-4757-ad49-ff1fbe57bbc0	31200	CASH	2025-09-19 00:00:00	2025-12-21 12:46:53.083	2025-12-21 12:46:53.083	\N
12983694-7c10-4c61-9a2a-c9f75bcd9f9a	5b572f43-7a5d-4757-ad49-ff1fbe57bbc0	100000	GPAY BOB	2025-09-19 00:00:00	2025-12-21 12:44:49.992	2025-12-21 12:44:49.992	\N
555ccc1e-022c-4979-9094-c516b31dcfb7	a0192846-41f5-4225-9617-dbab37257ea6	19000	GPAY BOB	2025-10-19 00:00:00	2025-12-21 12:49:38.999	2025-12-21 12:49:38.999	\N
80086250-8f38-45de-ae02-cb74f8e96c75	73c5f83f-f414-4576-a2d5-6e4ec33deff1	40000	GPAY BOB	2025-12-03 00:00:00	2025-12-21 12:57:52.059	2025-12-21 12:57:52.059	\N
1513a2a5-0630-46e2-9e24-4bc6d8c81f5c	73c5f83f-f414-4576-a2d5-6e4ec33deff1	10000	GPAY BOB	2025-12-05 00:00:00	2025-12-21 12:58:06.257	2025-12-21 12:58:06.257	\N
bd02d6c3-fa52-4c27-9003-8aa8d938fd8f	73c5f83f-f414-4576-a2d5-6e4ec33deff1	50000	GPAY BOB	2025-12-05 00:00:00	2025-12-21 12:59:07.9	2025-12-21 12:59:07.9	\N
085de219-e06d-48ed-b2d9-ba9547b86880	0357b2c4-4da3-4039-8b05-618288ceb163	50000	GPAY HDFC	2025-05-19 00:00:00	2025-12-21 13:08:19.708	2025-12-21 13:08:19.708	\N
b33bfe7e-a5b3-424b-b8c2-4d4ea7b8fd66	62373d6d-d66c-4e0d-89c0-df742f3aad63	84600	CASH	2025-06-16 00:00:00	2025-12-21 13:10:59.752	2025-12-21 13:10:59.752	\N
a7cd8ffd-3a58-4586-b4db-a816f5c57940	572241c2-1657-46cc-92af-e0052ef19a59	42600	CASH	2025-07-03 00:00:00	2025-12-21 13:13:25.974	2025-12-21 13:13:25.974	\N
70c2b609-6857-4ffb-bc45-761c0b8b5b33	c5c52416-34e3-4f1e-a8c0-57fdc82aaf05	70000	CASH	2025-06-18 00:00:00	2025-12-21 13:18:25.789	2025-12-21 13:18:25.789	\N
82cd21d3-20a2-47ef-86c2-0bfa4335b176	f7a1e6d9-b929-4e92-b8fd-d13feae5e2cd	20500	CASH	2025-07-15 00:00:00	2025-12-21 13:21:33.789	2025-12-21 13:21:33.789	\N
618832bf-83e5-440a-9dba-ed764552455b	f7a1e6d9-b929-4e92-b8fd-d13feae5e2cd	5000	HYDRO CASH	2025-07-15 00:00:00	2025-12-21 13:22:20.892	2025-12-21 13:22:20.892	\N
ca0d48cc-3ff9-4367-b526-0ef224ebf6ec	f7a1e6d9-b929-4e92-b8fd-d13feae5e2cd	30000	GPAY BOB	2025-07-18 00:00:00	2025-12-21 13:22:50.279	2025-12-21 13:22:50.279	\N
2c1dc882-8d4a-44c6-9ba1-7f1ef6ec93dc	0b04c3c2-8d93-4388-bde1-455f50f538eb	98318	GPAY HDFC	2025-11-25 00:00:00	2025-12-21 13:26:12.307	2025-12-21 13:26:12.307	\N
11362a68-384d-41aa-a5a7-6599237deaa1	988cfd30-2cba-4d96-a932-a145e3bec66d	86927	NEFT HDFC	2025-12-23 00:00:00	2025-12-23 13:55:21.607	2025-12-23 13:55:21.607	\N
7e6a00ba-544a-4ccc-8e42-c98598ea0b1c	c936abca-f1f9-4399-84ee-67195d26e293	13913	UPI PAYMENT BOB CHUKTE 	2025-12-22 00:00:00	2025-12-31 13:22:11.33	2025-12-31 13:22:11.33	\N
1502c024-00aa-4e2b-8e61-0e0c0cde3d7c	339b9f86-c4fa-4ce1-b1b2-804225524c85	14500	UPI PAYMENT BOB CHUKTE 	2025-12-31 00:00:00	2025-12-31 13:24:17.354	2025-12-31 13:24:17.354	\N
5097a458-1088-4b18-8cf6-241caa230d7c	5c598399-8062-4bf7-ab12-e9923946b693	191409	NEFT HDFC	2025-12-30 00:00:00	2026-01-01 04:12:26.363	2026-01-01 04:12:26.363	\N
5c084e11-e4aa-457d-a9c8-f90c90f2b65d	be38fa9e-75ce-43d7-b87b-bbb11ca890ef	19995	UIP Payment BOB chukte	2026-01-10 00:00:00	2026-01-10 05:15:56.901	2026-01-10 05:15:56.901	\N
\.


--
-- Data for Name: Subscription; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public."Subscription" (id, endpoint, p256dh, auth) FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: app_user
--

COPY public."User" (id, email, "createdAt", "updatedAt", password, username) FROM stdin;
215ed277-0f13-40ec-868e-bf9c0699151a	kishanpatel7705@gmail.com	2025-04-25 12:37:38.889	2025-04-25 12:37:38.889	shriram	shriram
06d94cd2-003a-4268-8051-e26012328dfa	patelmeet7697@gmail.com	2025-07-28 04:09:34.635	2025-07-28 04:09:34.635	meet	meet
\.


--
-- Name: Customer Customer_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_pkey" PRIMARY KEY (id);


--
-- Name: Expenses Expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."Expenses"
    ADD CONSTRAINT "Expenses_pkey" PRIMARY KEY (id);


--
-- Name: Invoice Invoice_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_pkey" PRIMARY KEY (id);


--
-- Name: Organization Organization_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_pkey" PRIMARY KEY (id);


--
-- Name: PaymentLog PaymentLog_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."PaymentLog"
    ADD CONSTRAINT "PaymentLog_pkey" PRIMARY KEY (id);


--
-- Name: Subscription Subscription_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."Subscription"
    ADD CONSTRAINT "Subscription_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: Customer_gstNumber_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Customer_gstNumber_idx" ON public."Customer" USING btree ("gstNumber");


--
-- Name: Customer_name_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Customer_name_idx" ON public."Customer" USING btree (name);


--
-- Name: Customer_userId_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Customer_userId_idx" ON public."Customer" USING btree ("userId");


--
-- Name: Expenses_expenseDate_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Expenses_expenseDate_idx" ON public."Expenses" USING btree ("expenseDate");


--
-- Name: Expenses_type_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Expenses_type_idx" ON public."Expenses" USING btree (type);


--
-- Name: Invoice_createdAt_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Invoice_createdAt_idx" ON public."Invoice" USING btree ("createdAt");


--
-- Name: Invoice_customerId_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Invoice_customerId_idx" ON public."Invoice" USING btree ("customerId");


--
-- Name: Invoice_invoiceNumber_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Invoice_invoiceNumber_idx" ON public."Invoice" USING btree ("invoiceNumber");


--
-- Name: Invoice_organizationId_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Invoice_organizationId_idx" ON public."Invoice" USING btree ("organizationId");


--
-- Name: Invoice_status_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Invoice_status_idx" ON public."Invoice" USING btree (status);


--
-- Name: Invoice_userId_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Invoice_userId_idx" ON public."Invoice" USING btree ("userId");


--
-- Name: Organization_gstNumber_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Organization_gstNumber_idx" ON public."Organization" USING btree ("gstNumber");


--
-- Name: Organization_gstNumber_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "Organization_gstNumber_key" ON public."Organization" USING btree ("gstNumber");


--
-- Name: Organization_userId_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "Organization_userId_idx" ON public."Organization" USING btree ("userId");


--
-- Name: PaymentLog_invoiceId_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "PaymentLog_invoiceId_idx" ON public."PaymentLog" USING btree ("invoiceId");


--
-- Name: PaymentLog_paymentDate_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "PaymentLog_paymentDate_idx" ON public."PaymentLog" USING btree ("paymentDate");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: app_user
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: app_user
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: Customer Customer_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."Customer"
    ADD CONSTRAINT "Customer_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Invoice Invoice_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public."Customer"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invoice Invoice_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public."Organization"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Invoice Invoice_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."Invoice"
    ADD CONSTRAINT "Invoice_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: Organization Organization_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."Organization"
    ADD CONSTRAINT "Organization_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: PaymentLog PaymentLog_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: app_user
--

ALTER TABLE ONLY public."PaymentLog"
    ADD CONSTRAINT "PaymentLog_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public."Invoice"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict WzdgxpsJq9yhB8IOrVQpOcv2nk8BMr3VQrtfHJxKvmGKGhuQD6oTvhdiKutGQYS

